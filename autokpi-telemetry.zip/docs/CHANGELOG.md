# Changelog

## 0.1.0 — Initial public version
- Synthetic telemetry dataset (8 laps, A/B setups)
- KPI computation
- Event detection and exceedances
- A/B comparison (Welch t, p-value approx)
- Simple OLS regression
- Markdown report aggregator
