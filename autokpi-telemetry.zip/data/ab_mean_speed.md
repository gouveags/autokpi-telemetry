# A/B Comparison for `mean_speed_mps`

| Setup | N | Mean | Std |
|------:|--:|-----:|----:|
| A | 4 | 52.285 | 1.987 |
| B | 4 | 55.112 | 3.457 |

Welch t-test: t = -1.418, df ≈ 4.8, p ≈ 0.1562 (normal approx).
