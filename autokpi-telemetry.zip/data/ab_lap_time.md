# A/B Comparison for `lap_time_s`

| Setup | N | Mean | Std |
|------:|--:|-----:|----:|
| A | 4 | 58.800 | 1.960 |
| B | 4 | 59.100 | 2.783 |

Welch t-test: t = -0.176, df ≈ 5.4, p ≈ 0.8601 (normal approx).
