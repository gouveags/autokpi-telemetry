# Code of Conduct (Short)

We are committed to a friendly, safe, and welcoming environment for all.

- Be respectful and considerate.
- No harassment, abuse, or discrimination.
- Assume good faith; be constructive and helpful.

Reports: open an issue or contact the maintainer privately.

This is a short community guideline inspired by the Contributor Covenant.
